#!/bin/sh

/koolshare/scripts/linkease_config.sh port
